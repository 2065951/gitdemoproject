package com.springbootsecondexample.secondexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondexampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondexampleApplication.class, args);
	}

}
