package com.springbootsecondexample.secondexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecondexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
