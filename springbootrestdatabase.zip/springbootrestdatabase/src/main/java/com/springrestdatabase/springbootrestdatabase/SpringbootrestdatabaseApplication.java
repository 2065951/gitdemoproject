package com.springrestdatabase.springbootrestdatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootrestdatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootrestdatabaseApplication.class, args);
	}

}
