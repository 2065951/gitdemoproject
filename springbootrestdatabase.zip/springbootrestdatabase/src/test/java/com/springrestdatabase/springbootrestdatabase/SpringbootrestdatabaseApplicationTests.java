package com.springrestdatabase.springbootrestdatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootrestdatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
